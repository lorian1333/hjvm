package pack;

public interface FakeInterfaceTwo
{
     public void InterfaceMethod1_Two();
     public void InterfaceMethod2_Two(int i);
}