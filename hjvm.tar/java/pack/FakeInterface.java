package pack;

public interface FakeInterface 
{
     public void InterfaceMethod1();
     public void InterfaceMethod2(int i);
}