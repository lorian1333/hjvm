#include <jcf.h>

static inline u8int check_magic(FILE* f)
{
	u8int *magic= (u8int*) malloc(4);
	READ_U4(magic, f);
	debugmsg("MAGIC = 0x%02X%02X%02X%02X\n", magic[0], magic[1], magic[2], magic[3]);
	if(magic[0]==0xCA && magic[1]==0xFE && magic[2]==0xBA && magic[3]==0xBE) {
		free(magic);
          debugmsg("MAGIC OK!\n");
		return 1;
	}
	else 
	{
		free(magic);
          debugmsg("WRONG MAGIC! Not a class file.\n");
		return 0;
	}
	
}

static inline void read_version(FILE* f, u16int* major, u16int* minor)
{

	u8int *minor_bytes = (u8int*) malloc(2), *major_bytes = (u8int*) malloc(2);
	READ_U2(minor_bytes, f);
	READ_U2(major_bytes, f);
	if(minor!=NULL) *minor = (minor_bytes[0]*0x100) | minor_bytes[1];
	if(major!=NULL) *major = (major_bytes[0]*0x100) | major_bytes[1];
	free(minor_bytes);
	free(major_bytes);
}

static inline void read_cp_count(FILE* f, u16int *cpcount)
{
	u8int *cpcount_bytes = (u8int*) malloc(2);
	READ_U2(cpcount_bytes, f);
	if(cpcount != NULL) *cpcount = MAKE_U16(cpcount_bytes);
	free(cpcount_bytes);
}

static inline void read_access_flags(FILE* f, u16int* accflags)
{
	u8int* acc_flag_bytes = (u8int*) malloc(2);
	READ_U2(acc_flag_bytes, f);
	if(accflags != NULL) *accflags = MAKE_U16(acc_flag_bytes);
	free(acc_flag_bytes);
}
static inline void read_this_and_super_class(FILE* f, u16int* this_class, u16int* super_class)
{
     u8int* bytes = (u8int*) malloc(2);
     READ_U2(bytes, f);
     if(this_class != NULL) *this_class =  MAKE_U16(bytes); 
     READ_U2(bytes, f);
     if(super_class != NULL) *super_class = MAKE_U16(bytes); 
     free(bytes);
}

static inline void read_interfaces_count(FILE* f, u16int *interfacescount)
{
	u8int *interfacescount_bytes = (u8int*) malloc(2);
	READ_U2(interfacescount_bytes, f);
	if(interfacescount != NULL) *interfacescount = MAKE_U16(interfacescount_bytes);
	free(interfacescount_bytes);
}

static inline void read_fields_count(FILE* f, u16int *fields_count)
{
     u8int* fieldscount_bytes = (u8int*) malloc(2);
     READ_U2(fieldscount_bytes, f);
     if(fields_count != NULL) *fields_count = MAKE_U16(fieldscount_bytes);
     free(fieldscount_bytes);
}

static inline void read_methods_count(FILE* f, u16int *methods_count)
{
     u8int* methodscount_bytes = (u8int*) malloc(2);
     READ_U2(methodscount_bytes, f);
     if(methods_count != NULL) *methods_count = MAKE_U16(methodscount_bytes);
     free(methodscount_bytes);
}

static inline void read_attributes_count(FILE* f, u16int *attributes_count)
{
     u8int* attributes_count_bytes = (u8int*) malloc(2);
     READ_U2(attributes_count_bytes, f);
     if(attributes_count != NULL) *attributes_count = MAKE_U16(attributes_count_bytes);
     free(attributes_count_bytes);
}
JavaClassFile* HjvmLoad(char* fn)
{
     /* Opening file */
	JavaClassFile* jcf = (JavaClassFile*) malloc(sizeof(JavaClassFile));
	jcf->fn = fn;
	verbosemsg("Loading classfile %s\n", fn);
	u16int i;
	FILE* f = fopen(fn, "rb");
	if(f==NULL)
	{
		errwithmsg("Unable to open file");
		return NULL;
	}
     /* Check if magic==ok */
	if(!check_magic(f))
	{
		debugerr("Invalid magic!\n");
		err("Invalid file");
		return NULL;
	}
     
     /* Read class version */
	u16int minor, major;
	read_version(f, &major, &minor);
	verbosemsg("Class version: %d.%d\n", major, minor);
	
	if(major < J2SE6) 
	{
		debugerr("Version too low!\n");
          err("Invalid file");
		return NULL;
	}
	else if(major > J2SE7 )
	{
		debugmsg("WARNING: Version > 51.0 (J2SE7)");
	}
	jcf->v_major = major;
     jcf->v_minor = minor;
	
	
	/* Read cpcount and constant_pool */
     
	u16int cpcount;
	read_cp_count(f, &cpcount);
	verbosemsg("Constant pool count: %d\n", cpcount);
     jcf->cpcount = cpcount;
     
	cp_info** cpinfo = (cp_info**) malloc( (cpcount-1) * sizeof(cp_info*));
	memset(cpinfo, 0, sizeof(cp_info*) * ( cpcount-1));

	if(!read_constant_pool(f, &i, &cpcount, cpinfo)) return NULL;
     jcf->cp = cpinfo;
   
     /* Read accessflags */
	u16int accflags;
	read_access_flags(f, &accflags);
     jcf->accflags = accflags;
     
	if(hjvm_be_extra_verbose())
	{     
	    char *public_str = "", *final_str = "", *super_str = "", *interface_str = "", *abstract_str = "";
		if(accflags & ACC_PUBLIC) public_str = "ACC_PUBLIC, ";
		if(accflags & ACC_FINAL) final_str = "ACC_FINAL, ";
		if(accflags & ACC_SUPER) super_str = "ACC_SUPER, ";
		if(accflags & ACC_INTERFACE) interface_str = "ACC_INTERFACE, ";
		if(accflags & ACC_ABSTRACT) abstract_str = "ACC_ABSTRACT, ";
        debugmsg("Access flags: %s%s%s%s%s\n", public_str, final_str, super_str, interface_str, abstract_str);
	}
	if(accflags & ACC_INTERFACE) 
	{
          debugmsg("This is classfile defines an interface\n");
		if(!(accflags & ACC_ABSTRACT))
		{
			debugerr("This classfile is an interface, but ACC_ABSTRACT was not set in access flags\n");
		}
		if(accflags & ACC_FINAL)
		{
			debugerr("This classfile is an interface, but ACC_FINAL also was set in access flags\n");
		}
		if(accflags & ACC_SUPER) 
		{
			debugerr("This classfile is an interface, but ACC_SUPER also was set in access flags\n");
		}
		if((accflags & ACC_FINAL) || (accflags & ACC_SUPER) || (!(accflags & ACC_ABSTRACT))) 
          {
               err("Incorrect file.\n");
               return NULL;
          }
		
	}
	else
	{
		debugmsg("This classfile defines a class\n"); 
		
		if( (accflags & ACC_FINAL) && (accflags & ACC_ABSTRACT))
		{
			debugerr("This classfile is a class, but ACC_FINAL and ACC_ABSTRACT were both set in access flags\n");
               err("Incorrect file.\n");
			return NULL; 
		}
		
	} 
	
     /* read this_class and super_class */
     
     u16int this_class, super_class;
     read_this_and_super_class(f, &this_class, &super_class);
     if(hjvm_be_verbose())
     {
          debugmsg("this_class = %d\n", this_class);
          debugmsg("super_class = %d\n", super_class);
          u16int utf8index = MAKE_U16(((CONSTANT_Class_info*)jcf->cp[this_class-1]->data)->name_index)-1;
          verbosemsg("This class: %s\n", ((CONSTANT_Utf8_info*)jcf->cp[utf8index]->data)->bytes);
          utf8index = MAKE_U16(((CONSTANT_Class_info*)jcf->cp[super_class-1]->data)->name_index)-1;
          verbosemsg("Superclass: %s\n", ((CONSTANT_Utf8_info*)jcf->cp[utf8index]->data)->bytes);
     }
     jcf->this_class = this_class;
     jcf->super_class = super_class;
     
     /* read interfaces_count and interfaces */
     
     u16int interfaces_count;
     read_interfaces_count(f, &interfaces_count);
     jcf->interfaces_count = interfaces_count;
     verbosemsg("Interfaces count: %d\n", interfaces_count);
     
     u16int *cp_index = (u16int*) malloc(sizeof(u16int));
     if(interfaces_count > 0)
     {
          interface_info** interfaceinfo = (interface_info**) malloc(interfaces_count * sizeof(interface_info*));
          if(!read_interfaces(f, interfaces_count, interfaceinfo)) return NULL;
          
         
          char* message = (char*) malloc(100);
          memset(message, 0, 100); 
          strcpy(message, "Interfaces: ");

          char* interfacename = (char*) malloc(100);
          memset(interfacename, 0, 100);
          
          if(hjvm_be_verbose())
          {
               for(i=0;i<interfaces_count;i++)
               {
                    
                    *cp_index = MAKE_U16(((CONSTANT_Class_info*) jcf->cp[interfaceinfo[i]->index-1]->data)->name_index);
                    strcpy(interfacename, ((CONSTANT_Utf8_info*) jcf->cp[(*cp_index)-1]->data)->bytes);
                   

                    if(i==0) sprintf(message, "%s%s", message, interfacename);
                    else sprintf(message, "%s, %s", message, interfacename);
                    
                   
               }
          }
          sprintf(message, "%s\n", message);
          verbosemsg(message);
          free(interfacename);
          free(message);
          
     }
     
    /* Read fields_count and fields */
    
    u16int fields_count;
    read_fields_count(f, &fields_count);
    verbosemsg("Fields count: %d\n", fields_count);
    jcf->fields_count = fields_count;
    field_info** fieldinfo = (field_info**) malloc(fields_count * sizeof(field_info*));
    
    if(!read_fields(f, fields_count, fieldinfo)) return NULL;
    
    jcf->fields = fieldinfo;
    
    /* Read methods_count and methods */
    
    u16int methodscount;
    read_methods_count(f, &methodscount);
    verbosemsg("Methods count: %d\n", methodscount);
    jcf->methods_count = methodscount;
    method_info** methodinfo = (method_info**) malloc(methodscount * sizeof(method_info*));
    
    if(!read_methods(f, methodscount, methodinfo)) return NULL;
    
    /* Read attributes_count and attributes */
    
    u16int attributescount;
    read_attributes_count(f, &attributescount);
    verbosemsg("Attributes count: %d\n", attributescount);
    jcf->attributes_count = attributescount;
    
    jcf->attributes = (attribute_info**) malloc(attributescount * sizeof(attribute_info*));
    if(!read_attributes(f, attributescount, jcf->attributes)) return NULL;
}



