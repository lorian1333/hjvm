#ifndef HJVM_H
#define HJVM_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <config.h>

#include <cp.h>
#include <interfaces.h>


int hjvm_verbose_level(void);







#endif

