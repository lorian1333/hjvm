#include <hjvm.h>
#include <jcf.h>
#include <time.h>
//#include <windows.h>

int be_verbose=0;
int be_extra_verbose;

const char* hjvm_executable_name;
#define EARG -1

void showhelp()
{
	printf("Usage: %s [options] file\n", hjvm_executable_name);
	puts("Options:");
     puts("   --help                            Show this help");
	puts("   -v, --verbose                     Be verbose"    );
     puts("   -xv, --extra-verbose              Be -extra- verbose. Enable debug messages"    );
     puts("   -c (dir), --classpath (dir)       Search for classfiles in this directory\n"
          "                                     and its subdirectories"    );
     puts("   -z (dir), --zip-archive (dir)     Search for classfiles in this ZIP archive");
     puts("");
 }
 char ** classpaths;
 int classpaths_count;
 char ** ziparchives;
 int ziparchives_count;
 char* mainfile;

int main(int argc, char *argv[])
{
     clock_t t1, t2;   
     t1 = clock();   
	hjvm_executable_name = argv[0];
     classpaths = (char**) malloc(100);
     memset(classpaths, 0, 100);
     ziparchives = (char**) malloc(100);
     memset(ziparchives, 0, 100);
	int i;
	if(argc==1) 
     {
		err("No input files. \nType --help for help.\n");
          return -EARG;
     }
     for(i=1;i<argc;i++)
     {
          if(strcmp(argv[i], "--help")==0)
               {
                    showhelp();
                    return 0;
               }
      }   
	for(i=1;i<argc-1;i++)
	{
		if(strcmp(argv[i], "--help")==0)
		{
			showhelp();
			return 0;
		}
          else if(strcmp(argv[i], "-v")==0 || strcmp(argv[i],"--verbose")==0)
			be_verbose=1;
           else if(strcmp(argv[i], "-xv")==0 || strcmp(argv[i],"--extra-verbose")==0)
           {
               be_verbose=1;
			be_extra_verbose=1;
           }
          else if(strcmp(argv[i], "-c")==0 || strcmp(argv[i], "--classpath")==0)
          {
               if(i+1 == argc-1) 
               {
                    err("%s should be followed by a directory. \nType --help for help.\n", argv[i]); 
                    return -EARG;
               }
               classpaths[classpaths_count++] = argv[++i];
          }
          else if(strcmp(argv[i], "-z")==0 || strcmp(argv[i], "--zip-archive")==0)
          {
               if(i+1 == argc-1) 
               {
                    err("%s should be followed by a path to a ZIP archive. \nType --help for help.\n", argv[i]);
                    return -EARG;
               }
               ziparchives[ziparchives_count++] = argv[++i];
          }
          else
          {
               err("Unrecognized command line option: \'%s\'. \nType --help for help.\n", argv[i]);
               return -EARG;
          }
          
	}

     verbosemsg("Current working directory: %s\n", getcwd(NULL, 1024));
     
     if(hjvm_be_verbose())
     {    
          if(classpaths_count>0) {
               verbosemsg("Classpaths included:\n");
               for(i=0;i<classpaths_count;i++)
                    verbosemsg("%s\n", classpaths[i]);
     
          }
          if(ziparchives_count>0) {
               verbosemsg("ZIP archives included:\n");
               for(i=0;i<ziparchives_count;i++)
                    verbosemsg("%s\n", ziparchives[i]);
          }
     }
     mainfile = argv[argc-1];
     
	JavaClassFile* jcf = HjvmLoad(mainfile); 
     
     //Sleep(1000);
     t2 = clock();   
     float diff = (((float)t2 - (float)t1) / 1000000.0F ) * 1000;   
     printf("Execution took approximately %f seconds\n", diff);
	return 0;
}

int hjvm_verbose_level(void)
{
	return be_verbose+be_extra_verbose;
}


/*
	cp_info* bla = (cp_info*) malloc(sizeof(cp_info));
	hmemset(bla, 0, sizeof(cp_info));
	debugmsg("%p\n", bla->data);
	bla->data = (u8int*) malloc(100);
	bla->data[0] = 'b';
	bla->data[1] = 'l';
	bla->data[2] = 'a';
	bla->data[3] = 0x00;
	debugmsg("%s\n", bla->data);
	*/