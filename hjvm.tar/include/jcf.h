#ifndef JCF_H
#define JCF_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <config.h>

#include <cp.h>
#include <interfaces.h>
#include <fields.h>
#include <methods.h>


enum JavaVersion {
	J2SE7 = 0x33,
	J2SE6 = 0x32,
	J2SE5 = 0x31,
	JDK1_4 = 0x30,
	JDK1_3 = 0x2F,
	JDK1_2 = 0x2E,
	JDK1_1 = 0x2D,
};

enum AccessFlags
{
	ACC_PUBLIC =    0x001,
     ACC_PRIVATE =   0x002,
     ACC_PROTECTED = 0x004,
     ACC_STATIC =    0x008,
	ACC_FINAL  =    0x010,
	ACC_SUPER  =    0x020,
     ACC_VOLATILE =  0x040,
     ACC_TRANSIENT = 0x080,
	ACC_INTERFACE = 0x200,
	ACC_ABSTRACT =  0x400,
};

typedef struct 
{
	char* fn;
	u16int v_major, v_minor;
	u16int cpcount;
	cp_info **cp;
     u16int accflags;
	u16int this_class;
	u16int super_class;
	u16int interfaces_count;
     interface_info** interfaces;
     u16int fields_count;
     field_info **fields;
     u16int methods_count;
     method_info **methods;
     u16int attributes_count;
     attribute_info **attributes;
	
} JavaClassFile;


JavaClassFile* HjvmLoad(char* fn);

#endif