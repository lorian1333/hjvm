#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <config.h>

#include <attributes.h>

int read_attributes(FILE* f, u16int attributes_count, attribute_info **attributeinfo)
{
     u8int* bytes = (u8int*) malloc(2);
     int i;
     attribute_info *info;
     size_t result;
     for(i=0;i<attributes_count;i++)
     {
          info = (attribute_info*) malloc(sizeof(attribute_info));
          READ_U2(bytes, f);
          info->attribute_name_index = MAKE_U16(bytes);
          READ_U4(bytes, f);
          info->attribute_length= MAKE_U32(bytes);
         
          info->info = (u8int*) malloc(info->attribute_length);
          result = fread((void*)info->info, 1, info->attribute_length, f);
          if(result != info->attribute_length) 
          {
               free(bytes);
               return 0;
          }
          debugmsg("#%d name:%d length:%d\n", (i+1), info->attribute_name_index, info->attribute_length);
          
          attributeinfo[i] = info;
     }
     return 1;
}